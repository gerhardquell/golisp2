# GoLisp2 – CLAUDE.md

Lisp-Interpreter in Go mit nativer KI-Anbindung (sigoREST).
Ziel: ein selbsterweiterndes System, das Goroutinen, Channels und KI-Calls
als eingebaute Lisp-Primitiven beherrscht.

**Autor:** Gerhard Quell – gquell@skequell.de · **CoAutor:** Claude
**Modul:** `golisp2` · **Sprache (Kommentare/Doku):** deutsch

> Diese Datei ist ein **Briefing**, kein Handbuch. Hier steht nur, was du
> nicht aus dem Code ableiten kannst. Alles andere: `doc/` (siehe unten).
> Wenn hier etwas dem Code widerspricht, gewinnt der Code — und die Datei
> gehört korrigiert.

---

## Orientierung

```
main.go              CLI: stdin / -i / -e / -t / --swank / Datei
cmd/golisp2d/        Server-Binary (SWANK-Daemon)
cmd/golisp2-client/  CLI-Client mit REPL
build/               Build-Artefakte (golisp2, golisp2d, golisp2-client)
lib/
  types*.go          Cell-Datenstruktur, Small-Int-Cache, Helfer
  reader.go          Parser: String → Cell-Baum
  env.go             Environment: verkettete Scopes, RWMutex
  eval_core.go       Eval-Trampolin, apply, evalArgs
  eval_*.go          Spezialformen, Lambda, Control, Quasiquote, load, exec
  primitives.go      Eingebaute Funktionen + BaseEnv()
  format*.go         FORMAT-Engine (CL-HyperSpec 22.3)
  <domäne>.go        goroutine, fileio, shellcmd, postgres, genalg, shm, sigorest
  stdlib.go          //go:embed stdlib.lisp
  readline.go        REPL (go-prompt, Highlighting, History)
  swank/             SWANK-Server für Emacs/SLIME
```

Vollständige Datei-für-Datei-Beschreibung: `doc/struktur.md`.
Im Zweifel: `rg` statt raten.

---

## Konventionen

- **Sprache:** Go für den Kern, Lisp für Erweiterungen
- **Einrückung:** 2 Spaces, keine Tabs
- **Dateinamen:** camelCase bzw. `snake_case` für Domänen-Suffixe (außer `main.go`)
- **Kommentare:** sparsam — sprechende Namen bevorzugt
- **Datei-Header:** Autor, CoAutor, Copyright, Erstellt (YYYYMMDD)
- **Fehler:** `fmt.Errorf("funktionsname: beschreibung")`
- **Build:** immer `./build.sh` (baut alle drei Binaries nach `./build/`)
- **tmp:** `./tmp/` verwenden — **nicht** `/tmp` !
- **Dateigröße:** Richtwert 800, hart bei 1000 Zeilen.
  *Bewusste Projektausnahme zur globalen 300/500-Regel:* Kohäsion schlägt
  Zeilenzahl. Zusammenhängender Code (z. B. die FORMAT-Engine) wird nicht
  auseinandergerissen, nur um eine Zahl zu treffen. Erst splitten, wenn ein
  echter Schnitt existiert.

### Wo kommt neuer Code hin?

- Braucht die Funktion `env`? → **Spezialform** in der passenden `eval_*.go`
  (`eval_specialforms.go`, `eval_control.go`, `eval_quasiquote.go`, …)
- Reine Berechnung ohne `env`? → **Primitiv** in `primitives.go`
- Gruppe verwandter Primitiven? → eigene Datei mit `RegisterXxx(env *Env)`
- **Neue Primitiven immer in `BaseEnv()` registrieren** — sonst existieren sie nicht.

---

## Invarianten — nicht versehentlich kaputtmachen

**TCO-Trampolin in `Eval()`**
Lambda-Calls und alle Tail-Spezialformen (`if`, `begin`, `let`, `cond`) setzen
`expr`/`env` und machen `continue` im `for {}`-Loop. Kein neuer Stack-Frame,
O(1) Stack bei beliebig tiefer Tail-Rekursion. Wer hier einen rekursiven
`Eval()`-Aufruf einbaut, zerstört das lautlos.

**`(eval form)` läuft im globalen Environment (`Env.Root()`)**
Nicht im dynamischen Lambda-Scope — Common-Lisp-Semantik. Notwendig, damit
Definitionen aus `(eval (read ...))` (REPL, `swank-repl:listener-eval`,
selbsterweiterndes Muster) global sichtbar bleiben und nicht im Child-Env der
aufrufenden Lambda-Kette verschwinden.

**Singleton-Nil**
`MakeNil()` gibt immer dieselbe Instanz zurück. `(eq '() '())` → `t`.
Nur lesen, nie modifizieren — sonst bricht `parfunc`.
Konsequenz: `eq` ist Pointer-Identität, `equal?` ist struktureller Vergleich.
Im Zweifel `equal?`.

**Multi-Body via `wrapBegin`**
`defun`/`lambda`/`defmacro` wrappen mehrere Body-Ausdrücke zur *Definitionszeit*
in `(begin ...)`. Einzelausdruck bleibt unverpackt (kein Overhead).

**Eval-Reihenfolge in `evalList`**
1. Spezialformen · 2. Makro-Expansion · 3. Normale Anwendung (Funktion → Args → apply)

---

## Build & Test

```bash
./build.sh                                 # alle Binaries → ./build/
go build ./...                             # Ground Truth für "kompiliert es?"
go test ./...                              # Unit-Tests
go test ./... -count=1                     # bei überraschenden Ergebnissen (Cache!)

./build/golisp2 -t                         # Lisp-Testsuite
./build/golisp2 -i                         # REPL (braucht TTY)
./build/golisp2 -e "(+ 1 2)"               # Expression
echo "(+ 1 2)" | ./build/golisp2           # stdin (Default)
./build/golisp2 skript.lisp                # Datei

./build/golisp2d --port 4321               # SWANK-Server
./build/golisp2-client --repl              # Client-REPL
```

Exit-Codes: `0` = Erfolg, `1` = Fehler. Fehler → stderr, Ergebnisse → stdout.

---

## Engineering-Prinzipien

**Wahrheitsquellen**
- `go build ./...` schlägt Language-Server-Diagnostiken (cross-file false positives).
- Tests sind die objektive Wahrheit: neues Verhalten → failing test zuerst;
  existierender Code → Charakterisierungstest, der das IST festhält.
- Test-Netz **vor** riskanten Refactorings. Tests ermöglichen mutige Änderungen,
  weil sie exakt zeigen, was bricht.
- Common-Lisp-Semantik ist der Kompass, wenn GoLisp-Verhalten unklar ist.

**Arbeitsweise**
- Minimal Changes: kleine, gezielte Änderungen sind robuster als Big-Bang.
- Erkundung vor Read-Loop; Blast-Radius prüfen vor Signaturänderungen.
- Eine Quelle schlägt Synchronisation: eine `LoadStdlib`, ein `IsTruthy`, keine Duplikate.
- **Breaking Changes und Design-Ausweitungen sind Gerhards Entscheidung** —
  fragen, mit Optionen und Preview.
- Diese CLAUDE.md schlägt Standard-Tools: nicht blind `gofmt`/LSP-Warnungen folgen.

**Performance**
- Benchmark-driven: messen, revertieren wenn keine Verbesserung. Nicht spekulieren.
- Nicht jede Allokation ist heap-allokiert. Pooling nur, wenn der Profiler Heap-Druck zeigt.
- Immutable Cells erlauben Sharing ohne semantische Brüche.

**Go-Gotchas (erlebte Bugs, keine Theorie)**
- `:=` im Loop-Body shadowed Variablen aus dem enclosing Block.
  Multi-Return-Assignments in Loops immer via Hilfsvariable + `=`.
- `strings.Builder` nie per Value kopieren — Pointer oder frische Instanz pro Sub-Kontext.
- Debug-Logs akkumulieren; nie die `err`-Variable oder ein Debug-Feld mit einem Log überschreiben.

**Protokoll-Arbeit**
- Client-Source lesen statt Spec raten. Trace (`>>`/`<<`) früh und bidirektional einbauen.
- Unit-Tests gegen Protokolle asserten Struktur, nicht Substrings.
- Synthetische Tests müssen echtes Verhalten modellieren (Pipelining, Multi-Event, Stateful Conns).

---

## Weiterführende Doku — bei Bedarf lesen, nicht vorsorglich

| Datei | Inhalt | Lies das, wenn … |
|-------|--------|------------------|
| `doc/struktur.md` | Datei-für-Datei-Beschreibung von `lib/` | du dich neu orientierst |
| `doc/cli.md` | Flags, Exit-Codes, Multiline-stdin, `exec`-Syntax | du an `main.go` arbeitest |
| `doc/swank.md` | SWANK-Protokoll, Framing, Op-Tabelle, SLIME-Details | du an `lib/swank/` arbeitest |
| `doc/sigo.md` | sigoREST: Env-Vars, Rate-Limiting, Multi-Host, Muster | du an `lib/sigorest.go` arbeitest |
| `doc/lisp-semantik.md` | `eq`/`equal?`, `let`/`let*`, `setq*`, `case`, FORMAT | Semantik unklar ist |
| `doc/memory.md` | GC-Verhalten, `(memstats)`, Best Practices | du Speicher untersuchst |
| `perfTodo.md` | Offene Performance-Arbeit | du optimierst |

### Was es bewusst *nicht* gibt

- **Keine Primitivenliste in der Doku.** Sie wäre ab dem nächsten
  `RegisterXxx()` falsch. Wahrheit ist der Code:
  `rg 'env\.Set\("' lib/` bzw. `(env-symbols)` zur Laufzeit.
- **Keine Modell-/Shortcode-Tabelle für `sigo`.** Provider deployen laufend
  neu. Wahrheit ist `(sigo-models)`.

---

## Philosophie

GoLisp2 ist ein **U-Boot-Projekt** — es reift in Ruhe, bevor es der Welt
gezeigt wird.

- **Nexialistisch:** Go-Effizienz + Lisp-Eleganz + KI-Power
- **Selbsterweiternd:** GoLisp2 vervollständigt sich durch KI-Calls selbst
- **Ensemble-fähig:** mehrere KIs parallel → Synthese
- **Centaur:** Mensch als Meta-Entscheider, KIs als Spezialisten

> „Code = Daten + KI = sich selbst erweiterndes System"
> – Gerhard & Claude, Juli 2026
